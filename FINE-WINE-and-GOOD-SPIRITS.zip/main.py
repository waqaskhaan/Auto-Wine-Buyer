import os
import re
import csv
import time
import yaml
# import random
# import smtplib
from selenium import webdriver
# from email.mime.text import MIMEText
from selenium.webdriver.common.by import By
# from email.mime.multipart import MIMEMultipart
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

#__________________________________________________________________________
# Load the YAML file
with open('config.yaml', 'r') as yaml_file:
    config_data = yaml.safe_load(yaml_file)

# # Email configuration
# email_sender = config_data.get('EMAIL_SENDER')
# email_receiver = config_data.get('EMAIL_RECIEVER')
# email_password = config_data.get('EMAIL_PASSWORD')

#Contact info
firstName = config_data.get('FIRST_NAME')
lastName = config_data.get('LAST_NAME')
email = config_data.get('EMAIL')
phone = config_data.get('PHONE')

#Shipping
businessName = config_data.get('BUSINESS_NAME')
Address = config_data.get('ADDRESS')
Street = config_data.get('STREET')
City = config_data.get('CITY')
Zip_Code = config_data.get('ZIP_CODE')

#Payment
Name_on_Card = config_data.get('NAME_ON_CARD')
Card_Number = config_data.get('CARD_NUMBER')
Security_Code = config_data.get('SECURITY_CODE')
Card_Expiry = config_data.get('CARD_EXPIRY')

#-------------------------------------------------------------------------------------

# Set up undetectable Chrome options
chrome_options = Options()
# chrome_options.add_argument("--headless")  # Run Chrome in headless mode
chrome_options.add_argument("--disable-blink-features=AutomationControlled")  # Disable automation detection
chrome_options.add_experimental_option("excludeSwitches", ["enable-automation"])
chrome_options.add_experimental_option('useAutomationExtension', False)

# Initialize Chrome driver with undetectable options
driver = webdriver.Chrome(options=chrome_options)

# Example wait before finding an element
wait = WebDriverWait(driver, 10)
driver.get('https://www.finewineandgoodspirits.com/home')
#-----------------------------------------------------------------------------------
urls = []
quantity = []
#----------------------------------------------

def top_ups(d):
    try:
        d.find_element(By.XPATH, '''//*[@id="ltkpopup-close-button"]''').click()
    except:
        pass
    time.sleep(1)
    try:
        d.find_element(By.CSS_SELECTOR, '''#root > header > section > div.header-desktop-wrapper > div.modal.fade.in.modal--active > div > div > div > div > div.age-gate__cta > button''').click()
    except:
        pass
    time.sleep(1)
    try:
        d.find_element(By.CSS_SELECTOR, '''#root > header > section > div.page-alert.cart__reversed > div > div.cart__reversed-close > button''').click()
    except:
        pass


# Function to fill contact info during add to cart
def Contact_INFO(driver_2, wait):
    try:
        wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, '#contact_info_profile-firstName')))
        driver_2.find_element(By.CSS_SELECTOR, '''#contact_info_profile-firstName''').click()
        driver_2.find_element(By.CSS_SELECTOR, '''#contact_info_profile-firstName''').clear()
        driver_2.find_element(By.CSS_SELECTOR, '''#contact_info_profile-firstName''').clear()
        driver_2.find_element(By.CSS_SELECTOR, '''#contact_info_profile-firstName''').send_keys(firstName)
    except:
        top_ups(driver_2)
        wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, '#contact_info_profile-firstName')))
        driver_2.find_element(By.CSS_SELECTOR, '''#contact_info_profile-firstName''').click()
        driver_2.find_element(By.CSS_SELECTOR, '''#contact_info_profile-firstName''').clear()
        driver_2.find_element(By.CSS_SELECTOR, '''#contact_info_profile-firstName''').clear()
        driver_2.find_element(By.CSS_SELECTOR, '''#contact_info_profile-firstName''').send_keys(firstName)
    
    try:
        wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, '#contact_info_profile-lastName')))
        driver_2.find_element(By.CSS_SELECTOR, '''#contact_info_profile-lastName''').click()
        driver_2.find_element(By.CSS_SELECTOR, '''#contact_info_profile-lastName''').clear()
        driver_2.find_element(By.CSS_SELECTOR, '''#contact_info_profile-lastName''').clear()
        driver_2.find_element(By.CSS_SELECTOR, '''#contact_info_profile-lastName''').send_keys(lastName) 
    except:
        pass

    # email
    try:
        wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, '#contact_info_profile-email')))
        driver_2.find_element(By.CSS_SELECTOR, '''#contact_info_profile-email''').click()
        driver_2.find_element(By.CSS_SELECTOR, '''#contact_info_profile-email''').clear()
        driver_2.find_element(By.CSS_SELECTOR, '''#contact_info_profile-email''').clear()
        driver_2.find_element(By.CSS_SELECTOR, '''#contact_info_profile-email''').send_keys(email)
    except:
        pass
    
    # Phone
    try:
        wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, '#contact_info_profile-phoneNumber')))
        driver_2.find_element(By.CSS_SELECTOR, '#contact_info_profile-phoneNumber').click()
        driver_2.find_element(By.CSS_SELECTOR, '#contact_info_profile-phoneNumber').clear()
        driver_2.find_element(By.CSS_SELECTOR, '#contact_info_profile-phoneNumber').click()
        time.sleep(1)
        driver_2.find_element(By.CSS_SELECTOR, '#contact_info_profile-phoneNumber').send_keys(phone)
        time.sleep(1)
    except:
        try:
            wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, '#contact_info_profile-phoneNumber')))
            driver_2.find_element(By.CSS_SELECTOR, '''#contact_info_profile-phoneNumber''').clear()
            driver_2.find_element(By.CSS_SELECTOR, '''#contact_info_profile-phoneNumber''').click()
            time.sleep(1)
            driver_2.find_element(By.CSS_SELECTOR, '''#contact_info_profile-phoneNumber''').send_keys(phone)
            time.sleep(1)
        except:
            pass

    time.sleep(1)
    driver_2.execute_script("window.scrollBy(0, 300);")
    # Use as contact info
    try:
        wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, '''#maincontent > section > div.checkoutContainer > section > section.Region.col-9 > div.contactInfo__wrapper > div.contactInfo__content > form > div > button''')))
        driver_2.find_element(By.CSS_SELECTOR, '''#maincontent > section > div.checkoutContainer > section > section.Region.col-9 > div.contactInfo__wrapper > div.contactInfo__content > form > div > button''').click()
    except:
        pass


# Shipping information
def Shipping(driver_2, wait):
    # My address checkpoint
    try:
        wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, '#shipToMyAddress')))
        driver_2.find_element(By.CSS_SELECTOR, '''#shipToMyAddress''').click()
    except:
        pass

    # First name
    try:
        wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, '#standardOrderAddressForm-firstName')))
        driver_2.find_element(By.CSS_SELECTOR, '''#standardOrderAddressForm-firstName''').click()
        driver_2.find_element(By.CSS_SELECTOR, '''#standardOrderAddressForm-firstName''').clear()
        driver_2.find_element(By.CSS_SELECTOR, '''#standardOrderAddressForm-firstName''').send_keys(firstName)
    except:
        pass

    # Last Name
    try:
        wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, '#standardOrderAddressForm-lastName')))
        driver_2.find_element(By.CSS_SELECTOR, '''#standardOrderAddressForm-lastName''').click()
        driver_2.find_element(By.CSS_SELECTOR, '''#standardOrderAddressForm-lastName''').clear()
        driver_2.find_element(By.CSS_SELECTOR, '''#standardOrderAddressForm-lastName''').send_keys(lastName)
    except:
        pass
    
    # Business name (Optional)
    try:
        wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, '#standardOrderAddressForm-companyName')))
        driver_2.find_element(By.CSS_SELECTOR, '''#standardOrderAddressForm-companyName''').click()
        driver_2.find_element(By.CSS_SELECTOR, '''#standardOrderAddressForm-companyName''').clear()
        driver_2.find_element(By.CSS_SELECTOR, '''#standardOrderAddressForm-companyName''').send_keys(businessName)
    except:
        pass

    # Address
    try:
        wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, '#standardOrderAddressForm-streetAddress')))
        driver_2.find_element(By.CSS_SELECTOR, '''#standardOrderAddressForm-streetAddress''').click()
        driver_2.find_element(By.CSS_SELECTOR, '''#standardOrderAddressForm-streetAddress''').clear()
        driver_2.find_element(By.CSS_SELECTOR, '''#standardOrderAddressForm-streetAddress''').send_keys(Address)
    except:
        pass

    # Street/Floor/Room
    try:
        wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, '#standardOrderAddressForm-suiteRoomFloor')))
        driver_2.find_element(By.CSS_SELECTOR, '''#standardOrderAddressForm-suiteRoomFloor''').click()
        driver_2.find_element(By.CSS_SELECTOR, '''#standardOrderAddressForm-suiteRoomFloor''').clear()
        driver_2.find_element(By.CSS_SELECTOR, '''#standardOrderAddressForm-suiteRoomFloor''').send_keys(Street)
    except:
        pass

    # City
    try:
        wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, '#standardOrderAddressForm-labelCity')))
        driver_2.find_element(By.CSS_SELECTOR, '''#standardOrderAddressForm-labelCity''').click()
        driver_2.find_element(By.CSS_SELECTOR, '''#standardOrderAddressForm-labelCity''').clear()
        driver_2.find_element(By.CSS_SELECTOR, '''#standardOrderAddressForm-labelCity''').send_keys(City)
    except:
        pass

    # Zip-Code
    try:
        wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, '#standardOrderAddressForm-labelZipCode')))
        driver_2.find_element(By.CSS_SELECTOR, '''#standardOrderAddressForm-labelZipCode''').click()
        driver_2.find_element(By.CSS_SELECTOR, '''#standardOrderAddressForm-labelZipCode''').clear()
        driver_2.find_element(By.CSS_SELECTOR, '''#standardOrderAddressForm-labelZipCode''').send_keys(Zip_Code)
    except:
        pass

    # Continue to Payment
    try:
        wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, '''#maincontent > section > div.checkoutContainer > section > section.Region.col-9 > div.shipping__wrapper > div.shipping__content > form > button''')))
        driver_2.find_element(By.CSS_SELECTOR, '''#maincontent > section > div.checkoutContainer > section > section.Region.col-9 > div.shipping__wrapper > div.shipping__content > form > button''').click()
    except:
        pass

    time.sleep(5)
    
    # Use Unverified Address
    try:
        unverified_address = driver.find_element(By.CSS_SELECTOR, '''#maincontent > section > div.checkoutContainer > section > section.Region.col-9 > div.shipping__wrapper > div.modal.fade.in.modal--active > div > div > div > div.shipping-modal__addresses > div.shipping-modal__entered-address.shipping-modal__zero-suggestions > button.button''')
        unverified_address.click()
    except:
        pass


# Payment information
def Payment(driver_2, wait):
    try:
        wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, '#input_general')))
        driver_2.find_element(By.CSS_SELECTOR, '''#input_general''').click()
        driver_2.find_element(By.CSS_SELECTOR, '''#input_general''').clear()
        driver_2.find_element(By.CSS_SELECTOR, '''#input_general''').send_keys(Name_on_Card)
    except:
        print("Error while input card name...")

    try:
        iframe = wait.until(EC.presence_of_element_located((By.ID, "tokenFrame")))
        driver.switch_to.frame(iframe)
    except:
        print("Error while switching iframe from default...")
        

    # Card Number
    try:
        wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, '#ccnumfield')))
        driver_2.find_element(By.CSS_SELECTOR, '''#ccnumfield''').click()
        driver_2.find_element(By.CSS_SELECTOR, '''#ccnumfield''').clear()
        driver_2.find_element(By.CSS_SELECTOR, '''#ccnumfield''').send_keys(Card_Number)
    except:
        print("error while input Card number...")

    # Security Code
    try:
        wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, '#cccvvfield')))
        driver_2.find_element(By.CSS_SELECTOR, '''#cccvvfield''').click()
        driver_2.find_element(By.CSS_SELECTOR, '''#cccvvfield''').clear()
        driver_2.find_element(By.CSS_SELECTOR, '''#cccvvfield''').send_keys(Security_Code)
    except:
        print("error while input security code...")

    try:
        print("Switching back to default iframe...")
        driver_2.switch_to.default_content()
    except:
        print("Error while switching back to default iframe....")

    # Card Expiry
    try:
        time.sleep(2)
        # wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, '#expDate')))
        driver_2.find_element(By.CSS_SELECTOR, '''#expDate''').click()
        driver_2.find_element(By.CSS_SELECTOR, '''#expDate''').clear()
        driver_2.find_element(By.CSS_SELECTOR, '''#expDate''').click()
        driver_2.find_element(By.CSS_SELECTOR, '''#expDate''').send_keys(Card_Expiry)
    except:
        print("error while input exp date...")

    # Place Order
    try:
        time.sleep(2)
        wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, '''#place-order-button''')))
        driver_2.find_element(By.CSS_SELECTOR, '''#place-order-button''').click()
    except:
        pass

    try:
        wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, '''#maincontent > section > div.checkoutContainer > section > section.Region.col-9 > div.payment__wrapper > div.payment__content > div > div.form-group.payment__submit-error > p''')))
        error_msg_place_order = driver_2.find_element(By.CSS_SELECTOR, '''#maincontent > section > div.checkoutContainer > section > section.Region.col-9 > div.payment__wrapper > div.payment__content > div > div.form-group.payment__submit-error > p''')
        print(error_msg_place_order.text)
    except:
        pass

# ---------------------------------- MAIN()----------------------------------------
def main():
    add_p = 'N'
    while True:
        p_url = input('Enter Product URL:')
        p_q = int(input('Enter Product Quantity:'))
        urls.append(p_url)
        quantity.append(p_q)
        add_p = str(input('Want to add another product? (Y/N)(Default = N):'))
        if add_p == 'N' or add_p == '':
            break

    time.sleep(5)    # ---> Apply any other logic of wait
    top_ups(driver)
    
    for url, Q in zip(urls, quantity):
        print(url, Q)
        driver.get(url)
        time.sleep(3)
        driver.execute_script("window.scrollBy(0, 300);")
        #check for available
        try:
            wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, '''#maincontent > section:nth-child(2) > div > div > div.pdp__info > div.pdp__info-quantity-availability > div > button''')))
            driver.find_element(By.CSS_SELECTOR, '''#maincontent > section:nth-child(2) > div > div > div.pdp__info > div.pdp__info-quantity-availability > div > button''').click()
        except:
            pass

        time.sleep(3)
        #Click on shipping-to
        try:
            wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, '''#root > header > section > div.header-desktop-wrapper > div.container-alignment > section:nth-child(1) > div > section > section > div.fulfillment-method > div.modal.fade.in.modal--active > div > div > div > div > div.popover__button > button:nth-child(2)''')))
            driver.find_element(By.CSS_SELECTOR, '''#root > header > section > div.header-desktop-wrapper > div.container-alignment > section:nth-child(1) > div > section > section > div.fulfillment-method > div.modal.fade.in.modal--active > div > div > div > div > div.popover__button > button:nth-child(2)''').click()
        except:
            print('error while clicking ship-to')

        # total available ---------------------------
        try:
            wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, '''#maincontent > section:nth-child(2) > div > div > div.pdp__info > div.pdp__info-quantity-availability > div.adding-to-cart > div.card__availability > div > div.availability-info''')))
            q = driver.find_element(By.CSS_SELECTOR, '''#maincontent > section:nth-child(2) > div > div > div.pdp__info > div.pdp__info-quantity-availability > div.adding-to-cart > div.card__availability > div > div.availability-info''')
            print(q.text)
        except:
            pass
        try:
            match = re.match(r'^\d+', q.text)
            if match:
                total_q = int(match.group())
    
            if total_q >= Q:
                Q = Q
            else:
                print(f'Total available quantity is {total_q} for product {url}, replacing your desired quantity with total quantity...')
                Q = total_q
        except:
            print('error while getting total available...')

        time.sleep(3)
        # updating quantity ------------------------------
        try:
            wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, '''#maincontent > section:nth-child(2) > div > div > div.pdp__info > div.pdp__info-quantity-availability > div.adding-to-cart > div.PDPAvailabilityOnline > div.form-group > div > button.button.square.button-secondary.square-up''')))
            q_up = driver.find_element(By.CSS_SELECTOR, '''#maincontent > section:nth-child(2) > div > div > div.pdp__info > div.pdp__info-quantity-availability > div.adding-to-cart > div.PDPAvailabilityOnline > div.form-group > div > button.button.square.button-secondary.square-up''')
            for i in range(Q-1):
                q_up.click()
        except:
            pass

        # Add to Card ----------------------------------------
        try:
            wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, '''#add-to-cart-wrapper > button''')))
            atc_btn = driver.find_element(By.CSS_SELECTOR, '''#add-to-cart-wrapper > button''').click()
        except:
            pass

        time.sleep(3)
        # continue shopping ---
        try:
            wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, '''#root > header > section > div.header-desktop-wrapper > div.container-alignment > section:nth-child(1) > div > section > section > div.miniCart-container > div.tooltipWrapper.clicked.active > div > div.tooltip-content.cartContent > section > section > section > div > button.link.cart-button''')))
            driver.find_element(By.CSS_SELECTOR, '''#root > header > section > div.header-desktop-wrapper > div.container-alignment > section:nth-child(1) > div > section > section > div.miniCart-container > div.tooltipWrapper.clicked.active > div > div.tooltip-content.cartContent > section > section > section > div > button.link.cart-button''').click()
        except:
            pass

    time.sleep(3)
    # ------------------ CHECKOUT ------------------------
    try:
        try:
            wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, '''#root > header > section > div.header-desktop-wrapper > div.container-alignment > section:nth-child(1) > div > section > section > div.miniCart-container > div.tooltipWrapper.clicked.active > div > div.tooltip-content.cartContent > section > section > section > div > button.button.cart-link''')))
            #if checkout window is pop-up
            checkout_btn = driver.find_element(By.CSS_SELECTOR, '''#root > header > section > div.header-desktop-wrapper > div.container-alignment > section:nth-child(1) > div > section > section > div.miniCart-container > div.tooltipWrapper.clicked.active > div > div.tooltip-content.cartContent > section > section > section > div > button.button.cart-link''')
            checkout_btn.click()
        except:
            wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, '''#updateProductListTooltip''')))
            #click on mini-cart button
            mini_cart = driver.find_element(By.CSS_SELECTOR, '''#updateProductListTooltip''')
            mini_cart.click()
            #then click on checkout-btn
            wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, '''#root > header > section > div.header-desktop-wrapper > div.container-alignment > section:nth-child(1) > div > section > section > div.miniCart-container > div.tooltipWrapper.clicked.active > div > div.tooltip-content.cartContent > section > section > section > div > button.button.cart-link''')))
            checkout_btn = driver.find_element(By.CSS_SELECTOR, '''#root > header > section > div.header-desktop-wrapper > div.container-alignment > section:nth-child(1) > div > section > section > div.miniCart-container > div.tooltipWrapper.clicked.active > div > div.tooltip-content.cartContent > section > section > section > div > button.button.cart-link''')
            checkout_btn.click()
    
    except:
        print('error while check-out')

    time.sleep(3)
    Contact_INFO(driver,wait)
    time.sleep(3)
    Shipping(driver,wait)
    time.sleep(3)
    Payment(driver,wait)
    time.sleep(4)
    driver.quit()

if __name__ == "__main__":
    main()

        
        
        
            
        



